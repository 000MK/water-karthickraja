import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent  implements OnInit {

  constructor(
    private router :Router
  ) {
    if (!localStorage.getItem('user')) {
     this.router.navigate([''])
    } else {
    this.router.navigate(['/dashboard'])
   }
  }

  ngOnInit() {
    var script1 = document.createElement('script');
    script1.id = 'toggle';
    script1.src = "assets/js/app.js";
    document.head.appendChild(script1);
  }

  logOut() {
    localStorage.removeItem("user");
    this.router.navigate([''])
  }

}
